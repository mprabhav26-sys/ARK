import React from 'react';
import { LearningStyle, UserSettings } from '../types';
import { Brain, Ear, Eye, Code, BookOpen, Sliders } from 'lucide-react';

interface SettingsPanelProps {
  settings: UserSettings;
  onUpdateSettings: (s: UserSettings) => void;
}

const SettingsPanel: React.FC<SettingsPanelProps> = ({ settings, onUpdateSettings }) => {
  
  const styles = [
    { id: LearningStyle.VISUAL, icon: Eye, label: 'Visual', desc: 'Diagrams & Analogies' },
    { id: LearningStyle.AUDITORY, icon: Ear, label: 'Auditory', desc: 'Conversational Audio' },
    { id: LearningStyle.THEORETICAL, icon: BookOpen, label: 'Theoretical', desc: 'Math & Definitions' },
    { id: LearningStyle.PRACTICAL, icon: Code, label: 'Practical', desc: 'Code & Implementation' },
  ];

  return (
    <div className="w-80 bg-slate-50 border-r border-slate-200 h-full flex flex-col hidden md:flex">
      <div className="p-6 border-b border-slate-200 bg-white">
        <div className="flex items-center gap-2 text-indigo-600 mb-1">
          <Brain size={24} />
          <h1 className="text-xl font-bold tracking-tight text-slate-900">NeuroLearn AI</h1>
        </div>
        <p className="text-xs text-slate-500">Adaptive Machine Learning Tutor</p>
      </div>

      <div className="p-6 flex-1 overflow-y-auto">
        <div className="flex items-center gap-2 mb-4 text-slate-800 font-semibold text-sm">
          <Sliders size={16} />
          <span>Learning Style</span>
        </div>
        
        <div className="space-y-3">
          {styles.map((style) => {
            const Icon = style.icon;
            const isSelected = settings.learningStyle === style.id;
            return (
              <button
                key={style.id}
                onClick={() => onUpdateSettings({ ...settings, learningStyle: style.id })}
                className={`w-full flex items-start p-3 rounded-xl border transition-all text-left ${
                  isSelected 
                    ? 'bg-indigo-50 border-indigo-500 ring-1 ring-indigo-500' 
                    : 'bg-white border-slate-200 hover:border-indigo-300'
                }`}
              >
                <div className={`p-2 rounded-lg mr-3 ${isSelected ? 'bg-indigo-100 text-indigo-600' : 'bg-slate-100 text-slate-500'}`}>
                  <Icon size={18} />
                </div>
                <div>
                  <div className={`font-medium text-sm ${isSelected ? 'text-indigo-900' : 'text-slate-700'}`}>
                    {style.label}
                  </div>
                  <div className="text-xs text-slate-500 mt-0.5">{style.desc}</div>
                </div>
              </button>
            );
          })}
        </div>

        <div className="mt-8">
          <div className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-4">Auto-Generations</div>
          
          <label className="flex items-center justify-between mb-4 cursor-pointer group">
            <span className="text-sm text-slate-700 group-hover:text-slate-900">Auto-Generate Visuals</span>
            <input 
              type="checkbox" 
              checked={settings.autoVisual}
              onChange={(e) => onUpdateSettings({...settings, autoVisual: e.target.checked})}
              className="w-4 h-4 text-indigo-600 rounded focus:ring-indigo-500 border-gray-300"
            />
          </label>

          <label className="flex items-center justify-between mb-4 cursor-pointer group">
            <span className="text-sm text-slate-700 group-hover:text-slate-900">Auto-Generate Audio</span>
            <input 
              type="checkbox" 
              checked={settings.autoAudio}
              onChange={(e) => onUpdateSettings({...settings, autoAudio: e.target.checked})}
              className="w-4 h-4 text-indigo-600 rounded focus:ring-indigo-500 border-gray-300"
            />
          </label>
        </div>
      </div>

      <div className="p-4 border-t border-slate-200 bg-slate-100 text-xs text-slate-400 text-center">
        Powered by Gemini 3 & 2.5
      </div>
    </div>
  );
};

export default SettingsPanel;
