import React, { useState, useEffect } from 'react';
import { ChatMessage, MessageRole } from '../types';
import MarkdownRenderer from './MarkdownRenderer';
import { Play, Square, Image as ImageIcon, Volume2, User, Bot, Loader2 } from 'lucide-react';
import { playPCMData } from '../utils/audioUtils';

interface MessageBubbleProps {
  message: ChatMessage;
}

const MessageBubble: React.FC<MessageBubbleProps> = ({ message }) => {
  const isUser = message.role === MessageRole.USER;
  const [isPlaying, setIsPlaying] = useState(false);
  const [audioContext, setAudioContext] = useState<AudioContext | null>(null);

  useEffect(() => {
    // Init audio context on user interaction if possible, or lazy load
    if (!audioContext && typeof window !== 'undefined') {
       const Ctx = window.AudioContext || (window as any).webkitAudioContext;
       if (Ctx) setAudioContext(new Ctx());
    }
  }, []);

  const handlePlayAudio = async () => {
    if (!message.relatedAudio || !audioContext) return;
    
    if (audioContext.state === 'suspended') {
      await audioContext.resume();
    }
    
    setIsPlaying(true);
    await playPCMData(message.relatedAudio, audioContext);
    setIsPlaying(false); // Simple toggle for now, ideal world needs event listener for end
  };

  return (
    <div className={`flex w-full mb-6 ${isUser ? 'justify-end' : 'justify-start'}`}>
      <div className={`flex max-w-[85%] md:max-w-[75%] gap-3 ${isUser ? 'flex-row-reverse' : 'flex-row'}`}>
        
        {/* Avatar */}
        <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 mt-1 shadow-sm ${isUser ? 'bg-indigo-600 text-white' : 'bg-emerald-600 text-white'}`}>
          {isUser ? <User size={16} /> : <Bot size={16} />}
        </div>

        {/* Content Bubble */}
        <div className={`flex flex-col gap-2`}>
          <div className={`p-4 rounded-2xl shadow-sm border ${
            isUser 
              ? 'bg-indigo-600 text-white border-indigo-500 rounded-tr-none' 
              : 'bg-white text-slate-800 border-slate-200 rounded-tl-none'
          }`}>
             {/* Text Content */}
            {isUser ? (
              <p className="whitespace-pre-wrap">{message.text}</p>
            ) : (
              message.isLoading ? (
                <div className="flex items-center gap-2 text-slate-500">
                  <Loader2 className="animate-spin" size={16} />
                  <span>Thinking...</span>
                </div>
              ) : (
                <MarkdownRenderer content={message.text} />
              )
            )}
          </div>

          {/* Attachments Area (Only for Model) */}
          {!isUser && !message.isLoading && (
            <div className="flex flex-wrap gap-2">
              
              {/* Generated Image */}
              {message.relatedImage && (
                <div className="w-full mt-2 rounded-xl overflow-hidden border border-slate-200 shadow-sm bg-white">
                  <div className="bg-slate-50 px-3 py-2 border-b border-slate-100 flex items-center gap-2 text-xs font-medium text-slate-500">
                    <ImageIcon size={14} />
                    <span>Visual Aid</span>
                  </div>
                  <img 
                    src={`data:image/png;base64,${message.relatedImage}`} 
                    alt="Generated explanation" 
                    className="w-full h-auto object-cover max-h-80"
                  />
                </div>
              )}

              {/* Generated Audio Player Button */}
              {message.relatedAudio && (
                 <button 
                  onClick={handlePlayAudio}
                  disabled={isPlaying}
                  className="flex items-center gap-2 px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-sm font-medium transition-colors border border-slate-200"
                 >
                   {isPlaying ? <Square size={16} className="fill-current"/> : <Play size={16} className="fill-current"/>}
                   <span>{isPlaying ? 'Playing Lesson...' : 'Listen to Explanation'}</span>
                   <Volume2 size={16} className="ml-1 opacity-50"/>
                 </button>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default MessageBubble;
