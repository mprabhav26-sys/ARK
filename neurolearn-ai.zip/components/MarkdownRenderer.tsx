import React from 'react';

interface MarkdownRendererProps {
  content: string;
}

const MarkdownRenderer: React.FC<MarkdownRendererProps> = ({ content }) => {
  // Very basic parser for the demo to avoid deps:
  // 1. Code blocks (```)
  // 2. Bold (**text**)
  // 3. Headers (###)
  // 4. Paragraphs

  const renderSegment = (text: string, index: number) => {
    // Simple inline bold parser
    const parts = text.split(/(\*\*.*?\*\*)/g);
    return (
      <span key={index}>
        {parts.map((part, i) => {
          if (part.startsWith('**') && part.endsWith('**')) {
            return <strong key={i} className="font-semibold text-indigo-700">{part.slice(2, -2)}</strong>;
          }
          return part;
        })}
      </span>
    );
  };

  const blocks = content.split(/(```[\s\S]*?```)/g);

  return (
    <div className="space-y-4 text-slate-700 leading-relaxed">
      {blocks.map((block, index) => {
        if (block.startsWith('```')) {
          const lines = block.split('\n');
          const lang = lines[0].replace('```', '').trim();
          const code = lines.slice(1, -1).join('\n');
          return (
            <div key={index} className="bg-slate-900 rounded-lg overflow-hidden my-4 shadow-sm border border-slate-800">
              {lang && <div className="bg-slate-800 px-4 py-1 text-xs text-slate-400 font-mono uppercase border-b border-slate-700">{lang}</div>}
              <pre className="p-4 overflow-x-auto text-sm font-mono text-emerald-400">
                <code>{code}</code>
              </pre>
            </div>
          );
        }

        // Process non-code blocks line by line for headers
        return block.split('\n').map((line, lineIdx) => {
          const trimmed = line.trim();
          if (!trimmed) return <div key={`${index}-${lineIdx}`} className="h-2" />; // Spacer

          if (trimmed.startsWith('### ')) {
            return <h3 key={`${index}-${lineIdx}`} className="text-lg font-bold text-slate-800 mt-4 mb-2">{trimmed.replace('### ', '')}</h3>;
          }
          if (trimmed.startsWith('## ')) {
            return <h2 key={`${index}-${lineIdx}`} className="text-xl font-bold text-slate-900 mt-5 mb-3 border-b pb-1 border-slate-200">{trimmed.replace('## ', '')}</h2>;
          }
          if (trimmed.startsWith('# ')) {
             return <h1 key={`${index}-${lineIdx}`} className="text-2xl font-bold text-slate-900 mt-6 mb-4">{trimmed.replace('# ', '')}</h1>;
          }
          if (trimmed.startsWith('- ')) {
            return <li key={`${index}-${lineIdx}`} className="ml-4 list-disc marker:text-indigo-500 pl-1 mb-1">{renderSegment(trimmed.replace('- ', ''), 0)}</li>;
          }

          return <p key={`${index}-${lineIdx}`} className="mb-2">{renderSegment(line, 0)}</p>;
        });
      })}
    </div>
  );
};

export default MarkdownRenderer;
