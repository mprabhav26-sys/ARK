import { GoogleGenAI, Modality } from "@google/genai";
import { LearningStyle } from "../types";
import { decodeBase64ToBytes } from "../utils/audioUtils";

// Initialize AI client function to ensure fresh key usage
const getAIClient = () => {
  const apiKey = process.env.API_KEY;
  if (!apiKey) {
    console.warn("API Key not found in environment variables.");
  }
  return new GoogleGenAI({ apiKey: apiKey || '' });
};

const SYSTEM_INSTRUCTION_BASE = `You are NeuroLearn, an expert Machine Learning tutor. 
Your goal is to explain complex ML concepts clearly and effectively. 
Format your response using Markdown. Use bold for key terms. 
If the user asks for code, provide Python code snippets wrapped in markdown code blocks.`;

const getSystemInstruction = (style: LearningStyle) => {
  switch (style) {
    case LearningStyle.VISUAL:
      return `${SYSTEM_INSTRUCTION_BASE} The user is a VISUAL learner. Use vivid analogies, metaphors, and descriptive language that evokes mental imagery. Focus on the "shape" and "structure" of concepts. Suggest what a diagram might look like in your text description.`;
    case LearningStyle.AUDITORY:
      return `${SYSTEM_INSTRUCTION_BASE} The user is an AUDITORY learner. Write in a conversational, podcast-like tone. Use rhythm and flow in your explanations. Keep sentences punchy and engaging as if being spoken.`;
    case LearningStyle.THEORETICAL:
      return `${SYSTEM_INSTRUCTION_BASE} The user is a THEORETICAL learner. Focus on mathematical foundations, proofs, and formal definitions. Be rigorous and precise.`;
    case LearningStyle.PRACTICAL:
      return `${SYSTEM_INSTRUCTION_BASE} The user is a PRACTICAL/CODE-FOCUSED learner. Prioritize "how-to" implementation. Provide Python code examples (using scikit-learn, pytorch, or pandas) early in the explanation. Explain the code line-by-line.`;
    default:
      return SYSTEM_INSTRUCTION_BASE;
  }
};

export const generateLessonContent = async (
  prompt: string,
  style: LearningStyle
) => {
  const ai = getAIClient();
  const systemInstruction = getSystemInstruction(style);

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
      config: {
        systemInstruction: systemInstruction,
        temperature: 0.7,
      },
    });
    return response.text;
  } catch (error) {
    console.error("Text generation error:", error);
    throw error;
  }
};

export const generateLessonAudio = async (text: string) => {
  const ai = getAIClient();
  try {
    // Summarize for audio first to keep it concise, if text is very long
    // But for this demo, we'll try to speak the raw text or a slightly shortened version.
    // Let's just speak the text provided (assuming the LLM kept it reasonable based on 'Auditory' instructions).
    
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash-preview-tts",
      contents: [{ parts: [{ text: text.slice(0, 1000) }] }], // Cap length for demo speed
      config: {
        responseModalities: [Modality.AUDIO],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: { voiceName: 'Kore' },
          },
        },
      },
    });

    const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
    if (base64Audio) {
      return decodeBase64ToBytes(base64Audio).buffer;
    }
    return null;
  } catch (error) {
    console.error("Audio generation error:", error);
    return null;
  }
};

export const generateLessonVisual = async (concept: string) => {
  const ai = getAIClient();
  try {
    const prompt = `A clear, educational diagram or illustration explaining the concept of: ${concept}. Clean, flat vector art style, white background, suitable for a textbook.`;
    
    // Using generateContent for nano banana series (gemini-2.5-flash-image) as per instructions
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash-image',
      contents: {
        parts: [{ text: prompt }],
      },
      config: {
        imageConfig: {
          aspectRatio: "4:3",
        }
      }
    });

    for (const part of response.candidates?.[0]?.content?.parts || []) {
      if (part.inlineData) {
        return part.inlineData.data; // Base64 string
      }
    }
    return null;
  } catch (error) {
    console.error("Image generation error:", error);
    return null;
  }
};
